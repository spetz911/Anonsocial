select * from  PERSONPAGE;
select * from PERSONPHOTO_1;
select * from ARTICLE;
select * from PERSONMESSAGE;
select * from CONCURS;
select * from PERSONPAGE_CONCURS;
select * from PERSONCOMMENT;
select * from STREET_USER;
select * from USERCOMMENT;

